#Write a program to check whether the input character is a vowel or consonant
char=input("Enter the char : ")
if char in 'a,e,i,o,u':
    print("Its a vowel")
else:
    print("itsa consonant")
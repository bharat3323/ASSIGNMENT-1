#Program 8: Write a program to check whether the number is greater than 10 or not
num=int(input("Enter the number: "))
if(num>10):
    print("yes",num,"is greater than 10")
else:
    print("no",num,"is less than 10")
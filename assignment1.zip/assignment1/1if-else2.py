###Write a Program to Find whether the number Is Even or Odd

num=int(input("Enter the num:"))
if(num%2==0):
    print({num},"number is even")
else:
    print({num},"number is odd")
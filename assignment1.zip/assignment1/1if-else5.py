#Write a Program to take an integer ranging from 0 to 6 and printcorresponding weekday (week starting from Monday)
for num in range(0,7):
    print(num)
num=int(input("enter the number : "))
if(num==0):
    print("monday")
if(num==1):
    print("tuesday")
if(num==2):
    print("wednesday")
if(num==3):
    print("thursday")
if(num==4):
    print("friday")
if(num==5):
    print("saturday")
if(num==6):
    print("sunday")
else:
    print("please enter the valid number")

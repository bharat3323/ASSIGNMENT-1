Input=input("Enter the input: ")
if Input.isalpha():
    print({Input},"is an alphabet")
else:
    print({},"is not alphabet")
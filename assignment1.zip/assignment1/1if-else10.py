#Program 10: WAP that determines whether a given input year is a leap year or no
Year=int(input("Enter the year: "))
if(Year%4==0):
    print(Year,"Year is leap year")
else:
    print(Year,"Year is not leap year")
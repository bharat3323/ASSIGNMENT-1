##Write a Program to Find a Maximum between two numbers

num1=int(input("Enter the num1="))
num2=int(input("Enter the num2="))
if(num1>num2):
    print("num1 is max number between",num1 ,num2 )
else:
     print("num2 is max number between",num1 ,num2 )
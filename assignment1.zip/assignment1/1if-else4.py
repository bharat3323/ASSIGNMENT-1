#Write a Program to check whether the number is divisible by 5or not.
num=int(input("Enter the number: "))
if(num%5==0):
    print({num},"Number is divisible by 5")
else:
    print("Number is not divisible 5")
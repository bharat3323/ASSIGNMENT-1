##Write a Program to check whether the number is Negative,Positive or equal to Zero.

num=int(input("Enter the num : "))
if(num>0):
    print({num},"is postive number")
elif(num<0):
    print({num},"is negative number")
else:
    print({num},"equal to zero")    